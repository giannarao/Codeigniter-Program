<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('/demo', 'Home::demo');

//$routes->get('/validateLogin', 'Login::validateLogin');

$routes->get('/login', 'Login::index');

$routes->get('/register', 'Register::register');


$routes->get('/items', 'Items::listItems');

$routes->post('/login/newLogin', 'Login::newLogin');

$routes->post('/register/newLogin', 'Register::create');


$routes->get('/viewCart', 'CartItems::listCart');

$routes->get('/checkout', 'Checkout::checkout');

$routes->get('/viewOrderHistory', 'OrderHistory::listOrders');

$routes->get('/addItem/(:any)/(:any)', 'Items::addItemToCart/$1/$2');