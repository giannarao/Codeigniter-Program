<?php

namespace App\Controllers;

class CartItems extends BaseController
{
    //public function viewCart(): string
    //{
      //  return view('cart_view');
    //}

    

    public function listCart($cart_cartID):string{
        
        $model = new \App\Models\CartItemsModel();
        //$cart_items = $model->listAllCartItems();

        $cart_items = $model->getOrderItems($cart_cartID);
        //d($cart_items);
        

        $data = [
            'cart_items'=>$cart_items
        ];

        return view ('cart_view', $data);
    }

    

}
?>