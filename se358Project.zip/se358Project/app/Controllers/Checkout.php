<?php

namespace App\Controllers;

class Checkout extends BaseController
{
    public function checkout(): string
    {
        return view('checkout_view');
    }

}
?>