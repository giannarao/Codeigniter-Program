<?php

namespace App\Controllers;

class Items extends BaseController
{
    


    public function listItems():string{
        
        $session = session();
        $memberInfo = $session->get('memberID');


        $model = new \App\Models\InventoryModel();
        $items = $model->listAllItems();
        //dd($items);

        $imgPath = 'http://localhost:8888/se358Project/' . 'public/images/';

        $data = [
            'items'=>$items,
            'imgPath'=>$imgPath, 
            'memberInfo'=>$memberInfo
        ];

        return view ('items_view', $data);
    }

     public function addItemToCart($memberInfo, $itemID){

        //call addOrGetCart ? 
        //call insert item to cart

        //$quantity 
        //"INSERT INTO cart_items (`cart_cartID`,`inventory_itemId`,`quantity`) VALUES (:cart_cartID:,:inventory_itemId:,:quantity:)";
        
        //memberID, itemID
        d($memberInfo, $itemID);

     }
}
?>