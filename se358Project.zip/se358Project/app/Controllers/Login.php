<?php

namespace App\Controllers;

//use App\Libraries\Authentication;

class Login extends BaseController
{
    public function index(): string
    {
		$data = [
			'message' => "Enter Login Credentials"
		];
		
		return view('login_view', $data);
    }




    
// newLogin()
public function newLogin () {
    	
		

  	   	$email = $this->request->getPost("email");
    	$password = $this->request->getPost("password");

		$model  = new \App\Models\CredentialsModel();
    	$validLogin = $model->validateLogin($email, $password);
    	//dd($validLogin);

		// $auth =  new Authentication();
		// $validLogin = $auth->login($email, $password);

    	if ($validLogin) {
			$session = session();
			d($validLogin);
			 $memberInfo = [
			 	"memberID"=> $validLogin[0] ['members_memberID']

			 ];
			 $session->set($memberInfo);
			
    		return redirect()->to("/items");
    	} 
    	else {
			$data = [
				'message' => "Login failed"
			];
			
    		return view('login_view', $data);

    	}
    }
    
    public function logout () {
  	    session()->destroy();
    	return redirect()->to(base_url());
    }
    

    
}

?>