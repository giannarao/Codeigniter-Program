<?php

namespace App\Controllers;

class OrderHistory extends BaseController
{
    // public function viewOrderHistory(): string
    // {
    //     return view('order_history_view');
    // }

    public function listOrders():string{
        
        $orderModel = new \App\Models\CheckoutModel();
        $orders = $orderModel->listOrders();
        //dd($orders);

        $data = [
            'orders'=>$orders
        ];

        return view ('order_history_view', $data);
    }

    public function getOrderInfo($checkoutOrderID){
    
        $orderItemsModel = new \App\Models\CartItemsModel();
        $orderItems = $orderItemsModel->getOrderItems();

        $data = [
            'orderItems'=>$orderItems
        ];

        return view('order_history_view', $data);
        

    }
}
?>