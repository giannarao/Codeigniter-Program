<?php

namespace App\Controllers;

class Register extends BaseController
{
    public function register(): string
    {
        return view('register_view');
    }


    public function create() {
    	

		$email = $this->request->getPost("email");
    	$password = $this->request->getPost("password");
    	$first_name = $this->request->getPost("first_name");
    	$last_name = $this->request->getPost("last_name");
    	$address = $this->request->getPost("address");
		$creditCardNum = $this->request->getPost("creditCardNum");
        //$expiration = $this->request->getPost("expiration");
		

    	$model = new \App\Models\MembersModel();
		$result = $model->addMember($email, $password, $first_name, $last_name, $address, $creditCardNum);

		// $cmodel = new \App\Models\CredentialsModel();
		// $result2 = $cmodel->addMember($email, $password);
		
		if ($result == true){
			return redirect()->to("/items"); 
		}
		else{
			return redirect()->to("/register");
		}

		// if ($result == true and $result2 == true){
		// 	return redirect()->to("/items"); 
		// }
		// else{
		// 	return redirect()->to("/register");
		// }

		
	}    

}
?>