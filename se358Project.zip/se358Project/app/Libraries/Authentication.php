<?php

namespace App\Libraries;

class Authentication {
	
	 public function isLoggedIn () {
  	    return services('auth')->isLoggedIn();
    }

	public function login($email, $password) {
		$model  = new \App\Models\credentials_model();
		$member = $model->validateLogin($email, $password);
    	$count = count($member);
    	if ($count > 0) {
    		$session = session();
    		$session->regenerate();	
    		$session->set("memberID", $member[0]['memberID']);
    		$member1 = $this->getMemberInfo($member[0]['memberID']);
    		$session->set("member", $member);
    		return true;
		} else {
			return false;
		}
	}
	
	public function loggedOut() {
		session()->destroy();
	}

    
} 

