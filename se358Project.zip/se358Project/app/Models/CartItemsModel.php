<?php

namespace App\Models;

use CodeIgniter\Model;

class CartItemsModel extends Model {

	protected $DBGroup = 'default';
    protected $table = "cart_items";
    //cart_items table
	protected $allowedFields = ['cart_cartID', 'inventory_itemId', 'quantity']; 
	protected $returnType = 'array';
	
	public function listAllCartItems(){

        //$cart_model = new \App\Models\CartItemsModel();

        $cart_items = $this->findAll();
        //d($cart_items);

        return $cart_items; 
    }
    
    public function getOrderItems($cart_cartID){

        $query = "SELECT inventory.itemName, cart_items.quantity FROM cart_items JOIN inventory ON cart_items.inventory_itemId = inventory.itemID WHERE cart_cartID=:cart_cartID:";
        $query = $this->db->query($query, ["cart_cartID"=>$cart_cartID]);
        $orderItems = $query->getResultArray();

        //returns item names in cart 

        return $orderItems;
        
    }
	
}

?> 