<?php

namespace App\Models;

use CodeIgniter\Model;

class CartModel extends Model {

	protected $DBGroup = 'default';
    protected $table = "cart";
	protected $allowedFields = ['cartID','members_memberID', 'status'];
	protected $returnType = 'array';
	
	

    public function listCart(){

        $cart = $this->db->findAll();
        
        return $cart; 
    }


    public function addOrGetCart($members_memberID){
        //check table for existing cart for the given members_memberID 
     
        
        $query = "SELECT cartID FROM `cart` WHERE members_memberID =:members_memberID:";

        //$query = "SELECT cartID FROM `cart` WHERE members_memberID is NOT NULL"

        $query = $this->db->query($query, ["members_memberID"=>$members_memberID]);
        $cart_id = $query->getResultArray();

        //return $cart_id;

        if(!empty($cart_id)){
            //if the member has a cart, get the cart
            $query = "SELECT * FROM `cart` WHERE members_memberID=:members_memberID:";
            $query = $this->db->query($query, ["members_memberID"=>$members_memberID]);
            $cart = $query->getResultArray();
            return cart;
        }

        else{
            //if the member does not have a cart, create a cart
            $status = "in progress";
            $query_insert = "INSERT INTO cart (`cartID`,`members_memberID`,`status`) VALUES (:cart_id:,:members_memberID:,:status:)";
            $query = $this->db->query($query, ["cartID"=>$cart_id, "members_memberID"=>$members_memberID, "status"=>$status]);
            $cart = $query->getResultArray();

            //insert first then update status ?

            return $cart;

        }
    }
}

?> 