<?php

namespace App\Models;

use CodeIgniter\Model;

class CheckoutModel extends Model {

	protected $DBGroup = 'default';
    protected $table = "checkout";
	protected $allowedFields = ['checkoutOrderID','checkoutDate', 'cart_cartID', 'members_memberID', 'totalPrice'];
	protected $returnType = 'array';
	
	

	public function listOrders(){

        $orders_model = new \App\Models\CheckoutModel();

        $orders = $orders_model->findAll();
        
        return $orders; 
    }

    




	
}

?> 