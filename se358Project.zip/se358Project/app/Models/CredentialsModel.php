<?php

namespace App\Models;

use CodeIgniter\Model;

class CredentialsModel extends Model {

	protected $DBGroup = 'default';
    protected $table = "credentials";
	protected $allowedFields = ['id','email','password', 'members_memberID'];
	protected $returnType = 'array';
	
	protected $validationRules = [
		"email" => 'required',
		"password" => 'required',
		"members_memberID" => 'required'
	];
	
	 public function addMember($email, $password, $members_memberID) {
	 	$query = "INSERT INTO credentials (`email`,`password`,`members_memberID`) VALUES (:email:,PASSWORD(:password:),:members_memberID:)";
		 //$query = "INSERT INTO credentials (`email`,`password`,`members_memberID`) VALUES ('email5@gmail.com',PASSWORD('pass'),'16')";
		
		$result=$this->db->query($query, ['email'=> $email, 'password'=>$password, 'members_memberID'=>$members_memberID]);
		d($result);

		// $this->insert([
		// 	'email' => $email,
		// 	"password" => $password,
		// 	'members_memberID' => $memberID
		// ]);

	
	 }















	
	public function validateLogin ($email, $password) {
		//$query = "SELECT members_memberID FROM ' . $this->table . ' WHERE email=:email AND password=PASSWORD(:password)";
		$query = "SELECT members_memberID FROM credentials WHERE email=:email: AND password=PASSWORD(:password:)";
		
		//$query = 'SELECT members_memberID FROM credentials WHERE email='name@gmail.com' AND password=PASSWORD('password')';
		//$query=$this->db->query($query);
		
		//dd($query);
		//$query = 'SELECT members_memberID FROM credentials where email=:email and password=PASSWORD(:password)'	//dd($query);
		
		$result=$this->db->query($query, ['email'=> $email, 'password'=>$password]);
		
  		$member = $result->getResultArray();
		//dd($member);
  		return $member;
	
	}









	
	
}

?>