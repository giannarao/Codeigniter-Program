<?php

namespace App\Models;

use CodeIgniter\Model;

class InventoryModel extends Model {

	protected $DBGroup = 'default';
    protected $table = "inventory";
	protected $allowedFields = ['itemId','itemName','itemDescription', 'itemSize', 'itemColor', 'itemPrice', 'imageName', 'amountAvailable', 'itemCategory'];
	protected $returnType = 'array';
	
	

    public function listAllItems(){

        $inventory_model = new \App\Models\InventoryModel();

        $items = $inventory_model->findAll();
        
        return $items; 
    }


	
}

?> 