<?php

namespace App\Models;

use CodeIgniter\Model;

class MembersModel extends Model {

	protected $DBGroup = 'default';
    protected $table = 'members';

	//protected $primaryKey = 'memberID';
	//protected $useAutoIncrement = true;

	protected $allowedFields = ['memberID','first_name', 'last_name', 'address','creditCardNum'];
	protected $returnType = 'array';
	
	//protected $allowEmptyInserts = false; 

	protected $validationRules = [
		"first_name" => 'required',
		"last_name" => 'required',
		"address" => 'required',
        "creditCardNum" => 'required'
	];

	protected $validationMessages = [
		"first_name" => [
			"required" => 'Please enter First Name'
		],
		"last_name" => [
			"required" => 'Please enter Last Name'
		],
		"address" => [
			"required" => 'Please enter address'
		],
		"creditCardNum" => [
			"required" => 'Please enter credit card number'
		],
	];

	public function addMember($email, $password, $first_name, $last_name, $address, $creditCardNum) {
		// $query = "INSERT INTO members ('memberID', `first_name, 'last_name', 'address', 'creditCardNum') VALUES ('$memberID', '$first_name', '$last_name', '$address', '$creditCardNum')";
  		// $query=$this->db->query($query);

		// $query_credentials = "INSERT INTO credentials ('email', 'password', 'members_memberID') VALUES ('$email', PASSWORD('$password'), '$memberID')";
        // $query_credentials = $this->db->query($query_credentials);




		//$model = new \App\Models\MembersModel();

    	$result = $this->insert([
    		'first_name' => $first_name,
    		"last_name" => $last_name,
    		"address" => $address,
    		"creditCardNum" => $creditCardNum
			
    	], false);

		//$memberID = $this->db->getInsertID();


        //$credentialsModel = new \App\Models\CredentialsModel();
        d($result);
    	
    	if ($result == false) {
    		//dd($this->errors);
    	}
    	else {
    		$memberID = $this->getInsertID();
    		$credentialsModel = new \App\Models\CredentialsModel();
    		$member = $credentialsModel->addMember($email,$password, $memberID);
    		//session()->setFlashData("info","New Member info added");
    		return $memberID; 
    		
    	}
    
 	}






	public function email_taken($email) {
		try {
		 $stmt = $this->db->prepare('SELECT email FROM credentials where email=:email');
		 $stmt->bindParam(':email', $email, PDO::PARAM_STR);
		 $stmt->execute();
		 $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		 if ($result && sizeof($result)>0) {
			 return true;
		 } else {
			 return false;
		 }
		} catch(PDOException $e) {
			 //var_dump($e->getMessage());
		}
   }
	
	
	
}

?>