<html>

    <head>
    
    <link rel="stylesheet" href="http://localhost:8888/se358Project/public/assets/css/tables.css">
   
        <title>Your Cart</title>
  
    </head>
    
    <table width='100%'><tr>
    <td align ='center'>Your Cart</td>


    <a href="login">Login Page</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="items">Items Page</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    
    <!-- <a href="checkout">Checkout</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     -->
    <a href="viewOrderHistory">Order History</a>

    

    </tr></table>
    <table width='100%' border="1">
   

    <tr><th>Item Name(ID)</th><th>Size</th><th>Price</th><th> Quantity </th><th>Remove From Cart</th>

    <tbody>


    <?php foreach ($cart_items as $cart) : ?>
<tr border='1'>


<td> <?= $cart['cart_cartID'] ?> </td>
<!-- put item id's here -->
<td> size </td>
<td> price </td>
<td> quantity </td>
<td> Remove from cart </td>



<?php endforeach ?>


</table>


<br>
Total Number of Items: <?php echo sizeof($cart_items) ?><br> 
Total Price:  


</html>
