<html>

<!-- THIS VIEW IS NOT BEING USED  -->

    <head>
    
        <title>Checkout</title>
  
    </head>
    
    <a href="login">Login Page</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="items">Items Page</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="viewCart">Cart</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="viewOrderHistory">Order History</a>


<form method="post" action=Checkout.php?action=checkout>
<fieldset>
    <legend>Checkout:</legend>
    <label for="numberOfItems">Number of Items:</label>
    <input type="text" id="numberOfItems" name="numberOfItems" value="1" size="10" ><br>
    <label for="totalPrice">Total Price:</label>
    <input type="text" id="totalPrice" name="totalPrice" value="$1" size="10" ><br>
    <label for="cvv">Enter CVV:</label>
    <input type="text" id="cvv" name="cvv" value="" size="10" ><br>
    





    <input type="submit" value="Checkout">






</html>
