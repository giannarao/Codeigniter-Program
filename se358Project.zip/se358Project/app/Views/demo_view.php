<html> 

<body>
    
    <?php

    //Demo message 
    $demo_message = "Demo Message 2";
    
    echo $demo_message;
    ?> 
    
</body>

</html>