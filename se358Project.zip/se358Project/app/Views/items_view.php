<html>
<head> 

<link rel="stylesheet" href="http://localhost:8888/se358Project/public/assets/css/tables.css">
    
    
<title>Items Page</title>

</head>

<body>

<table width='100%'><tr>
<td align ='center'>Items Page</td>

<a href="login">Login Page</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="viewCart">Cart</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

 <!-- <a href="checkout">Checkout</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     -->
     
<a href="viewOrderHistory">Order History</a>


</tr></table>
    <table width='100%' border="1">
    <tr><th>Image</th><th>Item Name</th><th>Color</th><th>Size</th><th>Price</th><th>Category</th><th>Quantity</th><th>Add to Cart?</th>

<tbody>


    <?php foreach ($items as $item) : ?>
        <?php $url = "addItem/" . $memberInfo . "/" . $item['itemId']; ?>
<tr border='1'>



<td><a href=<?= $imgPath ?><?= $item['imageName'] ?> ><img src=<?= $imgPath ?><?= $item['imageName'] ?> width='100'> </a></td>




<td> <?= $item['itemName'] ?> </td>
<td> <?= $item['itemColor'] ?> </td>
<td> <?= $item['itemSize'] ?> </td>
<td> <?= '$' . $item['itemPrice'] ?> </td>
<td> <?= $item['itemCategory'] ?> </td>
<td> <?= $item['amountAvailable'] ?> </td>
<td> <a href= <?= $url ?> >Add to Cart?</a></td>



<?php endforeach ?>




  
 

</table>

</body>
</hmtl>