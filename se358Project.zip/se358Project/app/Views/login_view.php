<!DOCTYPE html>
<html> 

    <head>

    <link rel="stylesheet" href="http://localhost:8888/se358Project/public/assets/css/login_style.css">
    
        <title>Login</title>
      
    </head>
   <body> 
    <section class = "login-clean">
<?= form_open("/login/newLogin") ?>
<fieldset>

    <!-- <legend>Ecommerce Login:</legend> -->

    <h2 align ='center'>Ecommerce Login</h2>

    <body align = 'center'>
    <label for="email">Email: </label> 


    <div class="mb-3"><input class="form-control" type="email" name="email"></div>
    
    <!-- <input type="text" id="email" name="email" value="" size="64" ><br> -->
    <br>

    <label for="password">Password: </label>
    <div class="mb-3"><input class="form-control" type="password" name="password"></div>
    
</body>
    <!-- <input type="password" name="password" value="" size="16"><br> -->
     

    <hr>
    
    <?= $message; ?>
    <div class="mb-3"><button class="btn btn-primary d-block w-100" type="reset">Reset</button></div>
    
    <div class="mb-3"><button class="btn btn-primary d-block w-100" type="submit">Log In</button></div>

</fieldset>
</form>

<br>




<a href="register">Register</a></div>

<?php
    //echo "hello";

?>

</body>

</html>



