<html>

    <head>
    
    <link rel="stylesheet" href="http://localhost:8888/se358Project/public/assets/css/tables.css">
   
    
        <title>Order History</title>
  
    </head>
    

    <a href="login">Login Page</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="items">Items Page</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="viewCart">Cart</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

     <!-- <a href="checkout">Checkout</a>&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     -->


    <table width='100%'><tr>
    <td align ='center'>Order History</td>


    </tr></table>
    <table width='100%' border="1">
    

    <tr><th>Order Number (checkoutID) </th><th>Total Price</th><th>Date</th>

    <?php foreach ($orders as $order) : ?>
<tr border='1'>


<td> <?= $order['checkoutOrderID'] ?> </td>
<!-- <td> <?= $order['cart_cartID'] ?> </td> -->
<td> <?= '$' . $order['totalPrice'] ?> </td>
<td> <?= $order['checkoutDate'] ?> </td>


<?php endforeach ?>







</html>
