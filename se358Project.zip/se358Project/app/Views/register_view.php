<html>

<head> 
    
<link rel="stylesheet" href="http://localhost:8888/se358Project/public/assets/css/login_style.css">

<title>Registration Page</title>   

    </head>


<a href="login">Login Page</a>

<body> 

<section class = "login-clean">
<?= form_open("/register/newLogin") ?>

    <fieldset> 
        <!-- <legend>Register: </legend>  -->
        <h2 align ='center'>Register</h2>

        <body align = 'center'>
        <label for="email">Email: </label> 
        <div class="mb-3"><input class="form-control" type="email" name="email"></div>

        <!-- <input type = "text" name = "email" value = ""> <br> -->
        <br>


        <label for="password">Password: </label> 
        <!-- <input type = "password" name = "password" value = ""> <br>  -->
        <div class="mb-3"><input class="form-control" type="password" name="password"></div> 
        <!-- <input type="password" name="password" value="" size="16"> <br> -->
        <br>


        
        <label for="first_name">First name: </label> 
        <div class="mb-3"><input class="form-control" type="first_name" name="first_name"></div> 
        <!-- <input type = "text" name = "first_name" value = ""> <br> -->
        <br>



        
        <label for="last_name">Last name: </label> 
        <div class="mb-3"><input class="form-control" type="last_name" name="last_name"></div> 
        <!-- <input type = "text" name = "last_name" value = ""> <br> --> 
        <br>



        <label for="address">Address: </label> 
        <div class="mb-3"><input class="form-control" type="address" name="address"></div> 
        <!-- <input type = "text" name = "address" value = ""> <br> -->
        <br>


        <label for="creditCardNum">Credit Card Num: </label> 
        <div class="mb-3"><input class="form-control" type="creditCardNum" name="creditCardNum"></div> 
        <!-- <input type = "text" name = "creditCardNum" value = ""> <br> -->
        <br>
      
        
        <!-- <label for="expiration">Expiration: </label> 
        <input type = "text" name = "expiration" value = ""> <br> -->

        <hr>
        <input type = "reset" value = "Reset"> 
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type = "submit" value = "Register"> 

        
</fieldset>
</form>




</body>

</html>